# $Id: mysql.sql 2297 2012-05-23 09:17:11Z cimorrison $

# Add the max number of bookings fields

ALTER TABLE %DB_TBL_PREFIX%area 
ADD COLUMN max_per_day_enabled       tinyint(1) DEFAULT 0 NOT NULL,
ADD COLUMN max_per_day               int DEFAULT 0 NOT NULL,
ADD COLUMN max_per_week_enabled      tinyint(1) DEFAULT 0 NOT NULL,
ADD COLUMN max_per_week              int DEFAULT 0 NOT NULL,
ADD COLUMN max_per_month_enabled     tinyint(1) DEFAULT 0 NOT NULL,
ADD COLUMN max_per_month             int DEFAULT 0 NOT NULL,
ADD COLUMN max_per_year_enabled      tinyint(1) DEFAULT 0 NOT NULL,
ADD COLUMN max_per_year              int DEFAULT 0 NOT NULL,
ADD COLUMN max_per_future_enabled    tinyint(1) DEFAULT 0 NOT NULL,
ADD COLUMN max_per_future            int DEFAULT 0 NOT NULL;
